/**
 * Popup.
 *
 * The page-world script owns the settings file. The popup never writes settings
 * directly, because two writers on one key diverge the moment both are used in
 * the same session. It asks the page to change the setting and re-reads the
 * result, so Kick Focus's own settings page stays the single source of truth.
 */

const els = {
  version: document.getElementById('version'),
  networkState: document.getElementById('network-state'),
  title: document.getElementById('network-title'),
  detail: document.getElementById('network-detail'),
  blocked: document.getElementById('blocked'),
  rulesets: document.getElementById('rulesets'),
  telemetry: document.getElementById('telemetry'),
  blocklistState: document.getElementById('blocklist-state'),
  blocklistUrl: document.getElementById('blocklist-url'),
  approveBlocklist: document.getElementById('approve-blocklist'),
  revokeBlocklist: document.getElementById('revoke-blocklist'),
  openSettings: document.getElementById('open-settings'),
  note: document.getElementById('note'),
};

const KICK_HOST = /^https:\/\/(www\.)?kick\.com\//;
const ACCENTS = Object.freeze({
  kick: ['#7cff2b', '124, 255, 43'],
  cyan: ['#38d7d0', '56, 215, 208'],
  violet: ['#9667ff', '150, 103, 255'],
  gold: ['#ffbe2e', '255, 190, 46'],
});

// Firefox exposes the promise-based `browser`; Chromium MV3 promisifies its own
// namespace. Either way this uses promises. Without the shim the Firefox popup
// queried tabs callback-style, got `undefined`, and rendered static defaults
// forever.
const api = globalThis.browser || globalThis.chrome;

function accentInk(hex) {
  const channels = String(hex).match(/[\da-f]{2}/gi)?.map((value) => Number.parseInt(value, 16) / 255);
  if (!channels || channels.length !== 3) return '#000000';
  const luminance = channels
    .map((value) => (value <= 0.04045 ? value / 12.92 : ((value + 0.055) / 1.055) ** 2.4))
    .reduce((sum, value, index) => sum + value * [0.2126, 0.7152, 0.0722][index], 0);
  const inkLuminance = (value) => value
    .map((part) => part / 255)
    .map((part) => (part <= 0.04045 ? part / 12.92 : ((part + 0.055) / 1.055) ** 2.4))
    .reduce((sum, part, index) => sum + part * [0.2126, 0.7152, 0.0722][index], 0);
  const contrast = (first, second) => (Math.max(first, second) + 0.05) / (Math.min(first, second) + 0.05);
  const dark = inkLuminance([0, 0, 0]);
  const light = 1;
  return contrast(luminance, dark) >= contrast(luminance, light) ? '#000000' : '#ffffff';
}

function applyAppearance(settings) {
  const appearance = settings?.appearance || {};
  const theme = ['studio', 'oled', 'slate'].includes(appearance.theme) ? appearance.theme : 'studio';
  const preset = ACCENTS[appearance.accent] || ACCENTS.kick;
  const custom = appearance.accent === 'custom' && /^#[\da-f]{6}$/i.test(appearance.customAccent || '')
    ? appearance.customAccent
    : '';
  const hex = custom || preset[0];
  const rgb = custom
    ? String(custom).match(/[\da-f]{2}/gi).map((value) => Number.parseInt(value, 16)).join(', ')
    : preset[1];
  document.documentElement.dataset.theme = theme;
  document.documentElement.style.setProperty('--accent', hex);
  document.documentElement.style.setProperty('--accent-rgb', rgb);
  document.documentElement.style.setProperty('--on-accent', accentInk(hex));
}

function renderUnavailable() {
  els.version.textContent = '';
  els.rulesets.textContent = 'Not available';
  els.blocked.textContent = 'Not available';
  els.networkState.dataset.state = 'off';
  els.networkState.textContent = 'Offline';
  els.title.textContent = 'Companion unavailable';
  els.detail.textContent = 'Reload the extension, then reopen this panel.';
  els.telemetry.disabled = true;
  els.approveBlocklist.disabled = true;
  els.revokeBlocklist.hidden = true;
  els.blocklistState.textContent = 'Unavailable';
  els.blocklistUrl.textContent = 'The companion service could not be reached.';
  els.openSettings.disabled = true;
  els.telemetry.title = 'Kick Focus could not reach the companion service';
  els.approveBlocklist.title = 'Kick Focus could not reach the companion service';
  els.openSettings.title = 'Kick Focus could not reach the companion service';
  els.note.textContent = 'No settings were changed.';
  document.body.setAttribute('aria-busy', 'false');
}

async function activeTab() {
  const [tab] = await api.tabs.query({ active: true, currentWindow: true });
  return tab || null;
}

function send(tabId, message) {
  return Promise.resolve(api.tabs.sendMessage(tabId, message))
    .then((response) => ({ ok: true, response }))
    .catch(() => ({ ok: false, response: null }));
}

async function render() {
  if (!api?.tabs?.query || !api?.runtime?.sendMessage) {
    renderUnavailable();
    return;
  }
  const tab = await activeTab();
  const onKick = Boolean(tab?.url && KICK_HOST.test(tab.url));

  const status = await Promise.resolve(api.runtime.sendMessage({
    type: 'kick-focus:status',
    tabId: tab?.id ?? -1,
  })).catch(() => null);

  if (!status) {
    renderUnavailable();
    return;
  }

  applyAppearance(status.settings);

  els.version.textContent = `v${status?.version ?? ''}`;
  els.rulesets.textContent = String(status?.rulesets?.length ?? 0);
  els.blocked.textContent = status?.countsAvailable ? String(status.blocked ?? 0) : 'Not available';

  const adsOn = status?.rulesets?.includes('ads');
  els.networkState.dataset.state = adsOn ? 'on' : 'off';
  els.networkState.textContent = adsOn ? 'Active' : 'Off';
  els.title.textContent = adsOn ? 'Network layer active' : 'Network layer off';
  els.detail.textContent = adsOn
    ? 'Ad requests are blocked before they are sent.'
    : 'The ad blocking rules are not enabled.';

  els.telemetry.checked = Boolean(status?.settings?.content?.reduceTelemetry);
  els.telemetry.disabled = !onKick;
  els.openSettings.disabled = !onKick;
  els.telemetry.title = onKick ? '' : 'Open a Kick tab to change this setting';
  els.openSettings.title = onKick ? '' : 'Open a Kick tab to open settings';

  const candidateUrl = status?.blocklist?.candidateUrl || '';
  const approvedUrl = status?.blocklist?.approvedUrl || '';
  const approved = Boolean(status?.blocklist?.approved);
  els.blocklistUrl.textContent = candidateUrl || 'Set an HTTPS feed in Kick Focus settings.';
  els.blocklistUrl.title = candidateUrl;
  els.blocklistState.textContent = approved ? 'Approved' : candidateUrl ? 'Approval needed' : 'Not configured';
  els.approveBlocklist.dataset.url = candidateUrl;
  els.approveBlocklist.disabled = !candidateUrl || approved;
  els.approveBlocklist.textContent = approved ? 'Feed approved' : 'Approve this feed';
  els.approveBlocklist.title = candidateUrl
    ? approved ? 'This exact feed is approved' : 'Allow this exact origin and feed URL'
    : 'Configure an HTTPS feed in settings first';
  els.revokeBlocklist.hidden = !approvedUrl;

  if (!onKick) {
    els.note.textContent = 'Open a Kick tab to change settings.';
  } else if (!status?.countsAvailable) {
    els.note.textContent = 'Blocked counts are only available when the extension is loaded unpacked.';
  } else {
    els.note.textContent = '';
  }
  document.body.setAttribute('aria-busy', 'false');
}

els.telemetry.addEventListener('change', async () => {
  const tab = await activeTab();
  if (!tab?.id) return;
  const wanted = els.telemetry.checked;
  els.telemetry.disabled = true;
  els.telemetry.setAttribute('aria-busy', 'true');
  els.note.textContent = 'Updating the network layer…';
  const result = await send(tab.id, { type: 'kick-focus:set-telemetry', enabled: wanted });
  if (!result.ok) els.note.textContent = 'Could not reach this Kick tab. Reload it and try again.';
  // Re-read rather than assume: the page is the authority on whether it stuck.
  setTimeout(() => {
    els.telemetry.removeAttribute('aria-busy');
    render();
  }, result.ok ? 150 : 1100);
});

els.approveBlocklist.addEventListener('click', async () => {
  const url = els.approveBlocklist.dataset.url || '';
  if (!url) return;
  let origin = '';
  try { origin = `${new URL(url).origin}/*`; } catch { return; }

  els.approveBlocklist.disabled = true;
  els.approveBlocklist.setAttribute('aria-busy', 'true');
  els.note.textContent = 'Waiting for origin permission…';
  const granted = await Promise.resolve(api.permissions.request({ origins: [origin] })).catch(() => false);
  if (!granted) {
    els.approveBlocklist.removeAttribute('aria-busy');
    els.approveBlocklist.disabled = false;
    els.note.textContent = 'Feed permission was not granted.';
    return;
  }

  const result = await Promise.resolve(api.runtime.sendMessage({
    type: 'kick-focus:approve-blocklist',
    url,
  })).catch(() => ({ ok: false }));
  if (!result?.ok) {
    await Promise.resolve(api.permissions.remove({ origins: [origin] })).catch(() => false);
  }
  els.approveBlocklist.removeAttribute('aria-busy');
  await render();
  els.note.textContent = result?.ok ? 'Remote blocklist feed approved.' : 'The feed changed before approval. Reopen the popup.';
});

els.revokeBlocklist.addEventListener('click', async () => {
  els.revokeBlocklist.disabled = true;
  els.note.textContent = 'Removing feed permission…';
  const result = await Promise.resolve(api.runtime.sendMessage({
    type: 'kick-focus:revoke-blocklist',
  })).catch(() => ({ ok: false }));
  await render();
  els.note.textContent = result?.ok ? 'Remote blocklist permission removed.' : 'Feed permission could not be removed.';
});

els.openSettings.addEventListener('click', async () => {
  const tab = await activeTab();
  if (!tab?.id) return;
  els.openSettings.disabled = true;
  els.openSettings.textContent = 'Opening settings…';
  const result = await send(tab.id, { type: 'kick-focus:open-settings' });
  if (result.ok) window.close();
  else {
    els.openSettings.disabled = false;
    els.openSettings.textContent = 'Open Kick Focus settings';
    els.note.textContent = 'Could not reach this Kick tab. Reload it and try again.';
  }
});

render().catch(renderUnavailable);
